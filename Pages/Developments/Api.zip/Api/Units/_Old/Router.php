<?php

// 30.10.2022




require_once __dir__ . '/Http/Http.php';




class Router {
  static public $_sessionId = 0;
  
  
  static public $user_name = 'admin';
  static public $user_password = 'DimaN_28121992';
  
  
  
  
  static public function _logIn() {
    $fetch_opts = [
      'body' => http_build_query([
        'password' => static::$user_password,
        'username' => static::$user_name,
        'submit.htm?login.htm' => 'Send',
      ]),
      'method' => 'POST',
    ];
    $response = Http::fetch('http://192.168.1.1/login.cgi', $fetch_opts);
    
    preg_match('/sessionId=(\d+)/i', $response['headers']['set-cookie'], $matches);
    static::$_sessionId = $matches[1];
  }
  
  
  
  
  static public function changeIp() {
    static::_logIn();
    
    $fetch_opts = [
      'body' => http_build_query([
        'pppifindex' => '14',
        'save' => 'Применить',
        'submit.htm?internet_connection.htm' => 'Send',
      ]),
      'headers' => [
        'Cookie' => 'SessionID=' . static::$_sessionId,
      ],
      'method' => 'POST',
    ];
    $response = Http::fetch('http://192.168.1.1/form2Changeppp.cgi', $fetch_opts);
    
    return $response;
  }
  
  
  static public function reboot() {
    static::_logIn();
    
    $fetch_opts = [
      'body' => http_build_query([
        'save' => 'Сохранить',
        'submit.htm?reboot.htm' => 'Send',
      ]),
      'headers' => [
        'Cookie' => 'SessionID=' . static::$_sessionId,
      ],
      'method' => 'POST',
    ];
    $response = Http::fetch('http://192.168.1.1/form2Reboot.cgi', $fetch_opts);
    
    return $response;
  }
}
