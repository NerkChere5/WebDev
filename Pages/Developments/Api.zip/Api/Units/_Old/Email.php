<?php

// 03.11.2022




require_once __dir__ . '/Http/Http.php';
require_once __dir__ . '/Json.php';




class Email {
  static public $_url = 'https://tempmail.plus/api/mails';
  
  
  
  
  static public function clear($email) {
    $fetch_opts = [
      'body' => http_build_query([
        'email' => $email,
        'first_id' => 1,
      ]),
      'method' => 'DELETE',
    ];
    $response = Http::fetch(static::$_url, $fetch_opts);
    
    return Json::parse($response['body']);
  }
  
  
  static public function get($email, $item_num = 0) {
    $item = null;
    
    while (!$item['is_new']) {
      $response = Http::fetch(static::$_url . "/?email=$email");
      $response_data = Json::parse($response['body']);
      
      $item = $response_data['mail_list'][$item_num];
      
      sleep(rand(Http::$_fetch_delay_min, Http::$_fetch_delay_max));
    }
    
    $item_id = $item['mail_id'];
    $response = Http::fetch(static::$_url . "/$item_id/?email=$email");
    $response_data = Json::parse($response['body']);
    
    return $response_data;
  }
}
