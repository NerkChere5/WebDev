import {Rest} from '../Rest/Rest.js';




class Test {
    _rest = new Rest('./Test.php');




    async main() {
        let data = await this._rest.call('db__create');

        console.log(data);
    }
}




let test = new Test();
test.main();
