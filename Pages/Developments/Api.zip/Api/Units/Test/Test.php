<?php

require_once '../Db.php';
require_once '../Rest/Rest.php';




class Test {
    final function db__create() {
        $db = new Db('sqlite:./Db.sqlite');

        $db->exec('
            create table if not exists test (
                a real,
                b text
            );
        ');

        $db->beginTransaction();

        for ($i = 0; $i < 1e3; $i++) {
            $db->query('
                insert into test (a, b)
                values (1, 2)
            ');
        }

        $db->commit();

        $db_statement = $db->query('
            select *
            from test
        ');
        $data = $db_statement->fetchAll(Db::FETCH_ASSOC);

        return $data;
    }
}




// $test = new Test();
// $rest = new Rest($test);
// $rest->run();

(new Rest(new Test()))->run();
