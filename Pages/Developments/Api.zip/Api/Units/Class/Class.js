// 25.09.2019


export class Class {
    static _maskTag = Symbol('maskTag');


    static _copyClass(TargetClass, SourceClass) {
        let propertyDescriptors = Object.getOwnPropertyDescriptors(SourceClass.prototype);
        let staticPropertyDescriptors = Object.getOwnPropertyDescriptors(SourceClass);

        delete staticPropertyDescriptors.prototype;

        Object.defineProperties(TargetClass, staticPropertyDescriptors);
        Object.defineProperties(TargetClass.prototype, propertyDescriptors);
    }

    static _getInheritanceChain(Class) {
        let inheritanceChain = [];

        while (Class.prototype && !Class.hasOwnProperty(this._maskTag)) {
            inheritanceChain.push(Class);

            Class = Object.getPrototypeOf(Class);
        }

        inheritanceChain.reverse();

        return inheritanceChain;
    }


    static mask(Class) {
        class Mask extends Class {}

        Mask[this._maskTag] = true;

        return Mask;
    }

    static mix(Class, ...mixins) {
        for (let Mixin of mixins) {
            let mixinInheritanceChain = this._getInheritanceChain(Mixin);

            for (let ChainClass of mixinInheritanceChain) {
                Class = class Mixin extends Class {};

                this._copyClass(Class, ChainClass);
            }
        }

        return Class;
    }
}
