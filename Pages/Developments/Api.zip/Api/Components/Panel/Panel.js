// 21.03.2021


import {Component} from '../Component/Component.js';
import {TrackBar} from '../TrackBar/TrackBar.js';


class Panel extends Component {
    static css = true;
    static components = [TrackBar];
    static html = true;
    static url = import.meta.url;


    static {
        this.init();
    }


    _animationFrame = 0;
    _scrollBars_values__define = this._scrollBars_values__define.bind(this);
    _scroll_x_factor = 0;
    _scroll_y_factor = 0;


    get scroll_x() {
        return this._elements.display.scrollLeft;
    }
    set scroll_x(scroll_x) {
        this._elements.display.scrollLeft = Math.round(scroll_x);
    }

    get scroll_y() {
        return this._elements.display.scrollTop;
    }
    set scroll_y(scroll_y) {
        this._elements.display.scrollTop = Math.round(scroll_y);
    }


    _init() {
        this._elements.display.addEventListener('scroll', this._on_scroll.bind(this));
        this._elements.scrollBar_x.addEventListener('value_changed', this._scrollBar_x__on_value_changed.bind(this));
        this._elements.scrollBar_y.addEventListener('value_changed', this._scrollBar_y__on_value_changed.bind(this));
        window.addEventListener('resize', this._window__on_resize.bind(this));

        this.refresh();
    }


    _on_scroll() {
        cancelAnimationFrame(this._animationFrame);
        this._animationFrame = requestAnimationFrame(this._scrollBars_values__define);
    }

    _scrollBar_x__on_value_changed() {
        this.scroll_x = this._elements.scrollBar_x.value * this._scroll_x_factor;
    }

    _scrollBar_y__on_value_changed() {
        this.scroll_y = this._elements.scrollBar_y.value * this._scroll_y_factor;
    }

    _scrollBars_values__define() {
        this._elements.scrollBar_x.value = this.scroll_x / this._scroll_x_factor;
        this._elements.scrollBar_y.value = this.scroll_y / this._scroll_y_factor;
    }

    _window__on_resize() {
        this.refresh();
    }


    refresh() {
        if (!this.visible__get()) return;

        this.attribute__set('_scroll_x', this._elements.display.clientWidth < this._elements.display.scrollWidth);
        this.attribute__set('_scroll_y', this._elements.display.clientHeight < this._elements.display.scrollHeight);
        this.attribute__set('_scroll_x', this._elements.display.clientWidth < this._elements.display.scrollWidth);

        this._elements.scrollBar_x.metrics__define();
        this._elements.scrollBar_y.metrics__define();
        let scrollBar_x_puck__length = Math.round(this._elements.display.clientWidth / this._elements.display.scrollWidth * this._elements.scrollBar_x._track_length);
        let scrollBar_y_puck__length = Math.round(this._elements.display.clientHeight / this._elements.display.scrollHeight * this._elements.scrollBar_y._track_length);
        this.style.setProperty('--_scrollBar_x_puck__length', scrollBar_x_puck__length);
        this.style.setProperty('--_scrollBar_y_puck__length', scrollBar_y_puck__length);
        this._elements.scrollBar_x.refresh();
        this._elements.scrollBar_y.refresh();

        this._scroll_x_factor = (this._elements.display.scrollWidth - this._elements.display.clientWidth) / this._elements.scrollBar_x._value_max;
        this._scroll_y_factor = (this._elements.display.scrollHeight - this._elements.display.clientHeight) / this._elements.scrollBar_y._value_max;
        this._scrollBars_values__define();
    }
}
