// 15.04.2023


import {Component} from '../Component/Component.js';
import {Model} from './Model.js';


export class Repeater extends Component {
    static attributes = ['model', 'regExp'];
    // static css = true;
    // static html = true;
    static url = import.meta.url;


    static {
        this.init();
    }


    _count = 0;
    _delegate_html = '';
    _delegate_selector = '[Repeater__delegate]';
    _model = new Model();
    _model_abortController = null;
    _modelData_selector = '[Repeater__model]';
    _regExp = /(?<!\$)\$(\w+)/g;
    _regExp_string = '';
    _template = document.createElement('template');


    item__init = (item, model_item) => {
        // item.textContent = model_item;
    };


    get items() {
        return this._elements.content.assignedElements();
    }

    get model() {
        return this._model;
    }
    set model(model) {
        this._model_abortController?.abort();
        this._model_abortController = new AbortController();

        if (typeof model != 'object') {
            this._model = +model;
            this.attribute__set('model', this._model);

            return;
        }

        this._model = model;
        this.attribute__set('model', null);

        let eventListener_opts = {signal: this._model_abortController.signal};
        this._model.addEventListener('added', this._model__on_added.bind(this), eventListener_opts);
    }

    get regExp() {
        return this._regExp_string;
    }
    set regExp(regExp) {
        this._regExp_string = regExp;
        this._regExp = new RegExp(this._regExp_string, 'g');
        this.attribute__set('regExp', this._regExp_string);
    }


    _delegate_html__define() {
        let element = this._template.content.querySelector(this._delegate_selector);
        // let element = this._elements.delegate.assignedElements()[0];

        if (!element) return;

        this._delegate_html = element.outerHTML;

        // console.log(this, this._delegate_html)
    }

    _init() {
        // this.model = this._model;
        this._template = this.querySelector('template');

        if (!this._template) return;

        // this.model = this._model;
        this._delegate_html__define();
        this._model_data__define();

        this.attributes__refresh();
        this.items__create();

        // this.addEventListener('click', (event) => console.log(this, event.target));
    }

    // init() {
    //     this.items__create();
    // }

    _item__create(model_item) {
        if (!this._delegate_html) return '';

        this._template.innerHTML = this._delegate_html.replace(this._regExp, (match, group) => model_item?.[group] ?? '');
        // this._template.innerHTML = this._delegate_html.replace(this._regExp, (match, group) => (console.log(match, group), model_item?.[group] ?? ''));

        let item = this._template.content.children[0];
        this.item__init?.(item, model_item);

        return item;
    }

    _model_data__define() {
        let script = this._template.content.querySelector(this._modelData_selector);

        if (!script) return;

        try {
            let data = new Function(`return (${script.text});`)();
            this.model.items__set(data);
        }
        catch {}

        // console.log(this.model)
    }

    _model__on_added(event) {
        let item = this._item__create(event.detail.item);
        let item_vice = this.items[event.detail.index];
        item_vice ? item_vice.before(item) : this.append(item);
    }


    items__create() {
        this.textContent = '';

        for (let model_item of this.model._items) {
            let item = this._item__create(model_item);
            this.append(item);

            // console.log(item)
        }
    }
}
