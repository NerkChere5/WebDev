// 23.04.2023


export class Model extends EventTarget {
    _items = [];


    filter_cond = null;
    sort_role = '';


    add(item, index = Infinity) {
        this._items.splice(index, 0, item);

        this.dispatchEvent(new CustomEvent('added', {detail: {index, item}}));
    }

    delete(index) {
        this._items.splice(index, 1);

        this.dispatchEvent(new CustomEvent('deleted', {detail: {index}}));
    }

    filter() {

    }

    items__set(items) {
        this._items = items;

        this.dispatchEvent(new CustomEvent('set'));
    }

    sort() {
        if (!this.sort_role) return;
    }

    update(index, data) {

    }
}
