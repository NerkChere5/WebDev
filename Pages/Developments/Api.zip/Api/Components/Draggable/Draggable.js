// 08.01.2023


import {Common} from '../../Units/Common/Common.js';
import {Component} from '../Component/Component.js';
import {Vector_2d} from '../../Units/Vector_2d/Vector_2d.js';


export class Draggable extends Component {
    static attributes = ['axis', 'disabled', 'handle_selector', 'step', 'step_x', 'step_y', 'unbounded'];


    static {
        this.init();
    }


    _axis = '';
    _disabled = false;
    _handle_selector = '';
    _pointer_base = new Vector_2d();
    _position = new Vector_2d();
    _position_base = new Vector_2d();
    _position_max = new Vector_2d();
    _step = 1;
    _step_x = 0;
    _step_y = 0;
    _unbounded = false;


    get axis() {
        return this._axis;
    }
    set axis(axis) {
        this._axis = typeof axis == 'string' ? axis : '';
        this.attribute__set('axis', this._axis || null);
    }

    get disabled() {
        return this._disabled;
    }
    set disabled(disabled) {
        this._disabled = disabled;
        this.attribute__set('disabled', this._disabled);
    }

    get handle_selector() {
        return this._handle_selector;
    }
    set handle_selector(handle_selector) {
        this._handle_selector = handle_selector ?? '';
        this.attribute__set('handle_selector', this._handle_selector || null);
    }

    get step() {
        return this._step;
    }
    set step(step) {
        this._step = +step || 1;
        this.attribute__set('step', this._step > 1 ? this._step : null);
    }

    get step_x() {
        return this._step_x;
    }
    set step_x(step_x) {
        this._step_x = +step_x ?? 0;
        this.attribute__set('step_x', this._step_x || null);
    }

    get step_y() {
        return this._step_y;
    }
    set step_y(step_y) {
        this._step_y = +step_y ?? 0;
        this.attribute__set('step_y', this._step_y || null);
    }

    get unbounded() {
        return this._unbounded;
    }
    set unbounded(unbounded) {
        this._unbounded = unbounded;
        this.attribute__set('unbounded', this._unbounded);
    }


    _init() {
        this.addEventListener('lostpointercapture', this._on_lostPointerCapture);
        this.addEventListener('pointerdown', this._on_pointerDown);
        this.addEventListener('touchmove', this._on_touchMove, {passive: false});

        this.attributes__refresh();
    }

    _on_lostPointerCapture() {
        this.drag__stop();

        this.dispatchEvent(new CustomEvent('drag_stop'));
    }

    _on_pointerDown(event) {
        if (this._disabled) return;

        try {
            let handle = event.target.closest(this._handle_selector);

            if (!this.contains(handle)) return;
        }
        catch {}

        this._position_max.x = Math.max(this.constructor.width_inner__get(this.offsetParent) - this.width_outer__get(), 0);
        this._position_max.y = Math.max(this.constructor.height_inner__get(this.offsetParent) - this.height_outer__get(), 0);
        this._pointer_base.init(event.pageX, event.pageY);
        this._position_base.init(this.left__get(), this.top__get());
        this._position.init_vector(this._position_base);

        this.addEventListener('pointermove', this._on_pointerMove);
        this.setPointerCapture(event.pointerId);

        event.stopPropagation();
        this.dispatchEvent(new CustomEvent('drag_start'));
    }

    _on_pointerMove(event) {
        if (this._axis != 'x') {
            let step = this._step_y || this._step;
            this._position.y = this._position_base.y + Math.round((event.pageY - this._pointer_base.y) / step) * step;
        }

        if (this._axis != 'y') {
            let step = this._step_x || this._step;
            this._position.x = this._position_base.x + Math.round((event.pageX - this._pointer_base.x) / step) * step;
        }

        if (!this._unbounded) {
            this._position.x = Common.toRange(this._position.x, 0, this._position_max.x);
            this._position.y = Common.toRange(this._position.y, 0, this._position_max.y);
        }

        this._position.round();
        this.left__set(this._position.x);
        this.top__set(this._position.y);

        this.attribute__set('_drag', true);
        this.dispatchEvent(new CustomEvent('drag'));
    }

    _on_touchMove(event) {
        event.preventDefault();
    }


    drag__stop() {
        this.attribute__set('_drag');
        this.removeEventListener('pointermove', this._on_pointerMove);
    }
}
