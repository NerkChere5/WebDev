// 18.03.2021


import {Common} from '../../Units/Common/Common.js';
import {Component} from '../Component/Component.js';
import {Draggable} from '../Draggable/Draggable.js';


export class TrackBar extends Component {
    static attributes = ['value_max', 'value_min', 'value', 'vertical'];
    static css = true;
    static components = [Draggable];
    static html = true;
    static url = import.meta.url;


    static {
        this.init();
    }


    _puck_length = 0;
    _track_length = 0;
    _value = 0;
    _value_max = 0;
    _value_min = 0;
    _vertical = false;


    get value() {
        return this._value;
    }
    set value(value) {
        this._value = Common.toRange(Math.round(value), this._value_min, this._value_max);
        this.attribute__set('value', this._value);
        this._puck_position__define();
    }

    get value_max() {
        return this._value_max;
    }
    set value_max(value_max) {
        this._value_max = value_max > this._value_min ? value_max : this._track_length - this._puck_length;
        this.attribute__set('value_max', this._value_max);
        this._puck_step__define();
        this.value = this._value;
    }

    get value_min() {
        return this._value_min;
    }
    set value_min(value_min) {
        this._value_min = value_min < this._value_max ? value_min : 0;
        this.attribute__set('value_min', this._value_min);
        this._puck_step__define();
        this.value = this._value;
    }

    get vertical() {
        return this._vertical;
    }
    set vertical(vertical) {
        this._vertical = !!vertical;
        this.attribute__set('vertical', this._vertical);
        this._elements.puck.axis = this._vertical ? 'y' : 'x';
        this._puck_position__define();
    }


    _init() {
        this._elements.puck.addEventListener('drag', this._puck__on_drag.bind(this));

        this.refresh();
    }

    _puck__on_drag() {
        let puck_position = this._vertical ? this._elements.puck._position.y : this._elements.puck._position.x;
        this.value = this._value_min + puck_position / this._elements.puck.step;

        this.dispatchEvent(new CustomEvent('value_changed'));
    }

    _puck_position__define() {
        let puck_position = Math.round(this._elements.puck.step * (this._value - this._value_min));

        if (this._vertical) {
            this._elements.puck.left__set();
            this._elements.puck.top__set(puck_position);
        }
        else {
            this._elements.puck.left__set(puck_position);
            this._elements.puck.top__set();
        }
    }

    _puck_step__define() {
        this._elements.puck.step = this._value_max > this._value_min ? (this._track_length - this._puck_length) / (this._value_max - this._value_min) : 1;
    }


    metrics__define() {
        if (this._vertical) {
            this._puck_length = this._elements.puck.height_outer__get();
            this._track_length = this.constructor.height_inner__get(this._elements.track);
        }
        else {
            this._puck_length = this._elements.puck.width_outer__get();
            this._track_length = this.constructor.width_inner__get(this._elements.track);
        }
    }

    refresh() {
        this.metrics__define();
        this.attributes__refresh();
    }
}
