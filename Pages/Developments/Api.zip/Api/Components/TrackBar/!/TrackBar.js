// 18.03.2021


import {Common} from '../../Units/Common/Common.js';
import {Component} from '../Component/Component.js';
import {Draggable} from '../Draggable/Draggable.js';


export class TrackBar extends Component {
    // static attributes = ['value', 'value_min', 'value_max', 'vertical'];
    static attributes = ['vertical', 'value_min', 'value_max', 'value'];
    static css = true;
    static components = [Draggable];
    static html = true;
    static url = import.meta.url;


    static {
        this.init();
    }


    _puck_length = 0;
    _track_length = 0;
    _value = 0;
    _value_max = 0;
    _value_min = 0;
    _vertical = false;


    get value() {
        return this._value;
    }
    set value(value) {
        this._value = Common.toRange(Math.round(value), this._value_min, this._value_max);
        this.attribute__set('value', this._value);
        this._puck_position__define();
    }

    get value_max() {
        return this._value_max;
    }

    get value_min() {
        return this._value_min;
    }

    get vertical() {
        return this._vertical;
    }
    set vertical(value) {
        this._vertical = !!value;
        this.attribute__set('vertical', this._vertical);

        this._elements.puck.axis = this._vertical ? 'y' : 'x';
        this._elements.puck.left__set();
        this._elements.puck.top__set();

        // this.value = this._value;
        this._puck_position__define();
    }


    _attributes_handler(name, value, value_prev) {
        if (name == 'value') {
            this.value = +value || this._value_min;
        }
        // else if (name == 'value_min') {
        //     this._disabled = value != null;
        // }
        else if (name == 'vertical') {
            this.vertical = value != null;
        }
    }

    _init() {
        this._elements.puck.addEventListener('drag', this._puck__on_drag.bind(this));
        // this.range__set(0, 0);
        // this.refresh();

        // console.log(this._value_min, this._value_max)

        this._metrics__define();
    }

    _metrics__define() {
        if (this._vertical) {
            this._puck_length = this._elements.puck.height_outer__get();
            this._track_length = this.constructor.height_inner__get(this._elements.track);
        }
        else {
            this._puck_length = this._elements.puck.width_outer__get();
            this._track_length = this.constructor.width_inner__get(this._elements.track);
        }

        this._puck_position_max = this._track_length - this._puck_length;
    }

    _puck__on_drag() {
        let puck_position = this._vertical ? this._elements.puck._position.y : this._elements.puck._position.x;
        this.value = this._value_min + puck_position / this._elements.puck.step;

        this.dispatchEvent(new CustomEvent('value_changed'));
    }

    _puck_position__define() {
        let puck_position = Math.round(this._elements.puck.step * (this._value - this._value_min));

        if (this._vertical) {
            this._elements.puck.left__set();
            this._elements.puck.top__set(puck_position);
        }
        else {
            this._elements.puck.left__set(puck_position);
            this._elements.puck.top__set();
        }
    }

    _puck_step__define() {
        this._elements.puck.step = this._value_max > this._value_min ? puck_position_max / (this._value_max - this._value_min) : 1;

    }

    attributes__apply() {
        this.vertical = this.attribute__get('vertical') ?? this.vertical;
        this.range__set(this.attribute__get('value_min'), this.attribute__get('value_max'));
        this.value = this.attribute__get('value') ?? this.value;
    }

    range__set(value_min, value_max) {
        // let puck_length = this._vertical ? this._elements.puck.height_outer__get() : this._elements.puck.width_outer__get();
        // let track_length = this._vertical ? this.constructor.height_inner__get(this._elements.track) : this.constructor.width_inner__get(this._elements.track);
        // let puck_position_max = track_length - puck_length;

        if (value_max > value_min) {
            this._value_max = value_max;
            this._value_min = value_min;
            this._elements.puck.step = puck_position_max / (this._value_max - this._value_min);
        }
        else {
            this._value_max = puck_position_max;
            this._value_min = 0;
            this._elements.puck.step = 1;
        }

        // this.value = this._value;
        this._puck_position__define();
    }

    // refresh() {
    //     if (!this._built) return;

    //     // console.log('refresh')

    //     let puck_position = Math.round(this._elements.puck.step * (this._value - this._value_min));
    //     this._vertical ? this._elements.puck.top__set(puck_position) : this._elements.puck.left__set(puck_position);
    // }
}
