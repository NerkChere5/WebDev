// 24.09.2022

import {Component} from '../Component.js';




export class Stack extends Component {
  static url = import.meta.url;
  
  
}




Stack.init();
