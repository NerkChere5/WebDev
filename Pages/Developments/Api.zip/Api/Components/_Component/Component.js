import {Component} from '../Component.js';


export class Component_new extends Component {
    static css = true;
    static html = true;
    static observedAttributes = [];
    static url = import.meta.url;


    static {
        this.init();
    }


    _init() {

    }
}
