// 08.01.2023

import {Common} from '../../Units/Common.js';
import {Component} from '../Component/Component.js';
import {Vector_2d} from '../../Units/Vector_2d.js';


export class Draggable extends Component {
    static observedAttributes = ['axis', 'disabled', 'handle_selector', 'step_x', 'step_y', 'unbounded'];


    static {
        this.init();
    }


    _disabled = false;
    _pointer_base = new Vector_2d();
    _position = new Vector_2d();
    _position_base = new Vector_2d();
    _position_max = new Vector_2d();
    _unbounded = false;


    axis = '';
    handle_selector = '*';
    step_x = 1;
    step_y = 1;


    get disabled() {
        return this._disabled;
    }

    set disabled(value) {
        this._disabled = value;
        this.attribute__set('disabled', this._disabled);
    }


    get handle_selector() {
        return this._handle_selector;
    }

    set handle_selector(value) {
        this._handle_selector = value;
        this.attribute__set('handle_selector', this._handle_selector);
    }


    get unbounded() {
        return this._unbounded;
    }

    set unbounded(value) {
        this._unbounded = value;
        this.attribute__set('unbounded', this._unbounded);
    }


    _init() {
        this.addEventListener('lostpointercapture', this._on_lostPointerCapture);
        this.addEventListener('pointerdown', this._on_pointerDown);
        this.addEventListener('touchmove', this._on_touchMove, {passive: false});

        this.attributes__apply();
    }

    _on_lostPointerCapture() {
        this.drag__stop();

        this.dispatchEvent(new CustomEvent('drag_stop', {bubbles: true}));
    }

    _on_pointerDown(event) {
        if (this._disabled) return;

        let handle = event.target.closest(this.handle_selector);

        if (!this.contains(handle)) return;

        this._position_max.x = this.constructor.width_inner__get(this.offsetParent) - this.width_outer__get();
        this._position_max.y = this.constructor.height_inner__get(this.offsetParent) - this.height_outer__get();
        this._pointer_base.init(event.pageX, event.pageY);
        this._position_base.init(this.left__get(), this.top__get());
        this._position.init_vector(this._position_base);

        this.addEventListener('pointermove', this._on_pointerMove);
        this.setPointerCapture(event.pointerId);

        event.stopPropagation();
        this.dispatchEvent(new CustomEvent('drag_start', {bubbles: true}));
    }

    _on_pointerMove(event) {
        if (this.axis != 'x') {
            this._position.y = this._position_base.y + Math.round((event.pageY - this._pointer_base.y) / this.step_y) * this.step_y;
        }

        if (this.axis != 'y') {
            this._position.x = this._position_base.x + Math.round((event.pageX - this._pointer_base.x) / this.step_x) * this.step_x;
        }

        if (!this._unbounded) {
            this._position.x = Common.toRange(this._position.x, 0, this._position_max.x);
            this._position.y = Common.toRange(this._position.y, 0, this._position_max.y);
        }

        this.attribute__set('_drag', true);
        this.left__set(this._position.x);
        this.top__set(this._position.y);

        this.dispatchEvent(new CustomEvent('drag', {bubbles: true}));
    }

    _on_touchMove(event) {
        event.preventDefault();
    }


    // attributes_callbacks = {
    //     axis:
    // };

    attributeChangedCallback(name, value_prev, value) {
        if (value == value_prev) return;

        if (name == 'axis') {
            this.axis = value;
        }
    }

    attributes__apply() {
        this._disabled = this.hasAttribute('disabled');
        this._unbounded = this.hasAttribute('unbounded');
        this.axis = this.getAttribute('axis') ?? this.axis;
        this.handle_selector = this.getAttribute('handle_selector') ?? this.handle_selector;
        this.step_x = this.attribute_number__get('step_x') ?? this.step_x;
        this.step_y = this.attribute_number__get('step_y') ?? this.step_y;
    }

    attributes__update() {
        this.attribute__set('axis', this.axis);
        this.attribute__set('disabled', this.disabled);
        this.attribute__set('handle_selector', this.handle_selector);
        this.attribute__set('step_x', this.step_x);
        this.attribute__set('step_y', this.step_y);
        this.attribute__set('unbounded', this.unbounded);
    }

    drag__stop() {
        this.attribute__set('_drag');
        this.removeEventListener('pointermove', this._on_pointerMove);
    }
}
