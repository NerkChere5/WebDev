// 08.01.2023


import {Common} from '../../Units/Common/Common.js';
import {Component} from '../Component/Component.js';
import {Vector_2d} from '../../Units/Vector_2d/Vector_2d.js';


export class Draggable extends Component {
    static observedAttributes = ['axis', 'disabled', 'handle_selector', 'step', 'step_x', 'step_y', 'unbounded'];


    static {
        this.init();
    }


    _pointer_base = new Vector_2d();
    _position = new Vector_2d();
    _position_base = new Vector_2d();
    _position_max = new Vector_2d();


    axis = '';
    disabled = false;
    handle_selector = '';
    step = 1;
    step_x = 0;
    step_y = 0;
    unbounded = false;


    _init() {
        this.addEventListener('lostpointercapture', this._on_lostPointerCapture);
        this.addEventListener('pointerdown', this._on_pointerDown);
        this.addEventListener('touchmove', this._on_touchMove, {passive: false});
    }

    _on_lostPointerCapture() {
        this.drag__stop();

        this.dispatchEvent(new CustomEvent('drag_stop'));
    }

    _on_pointerDown(event) {
        if (this.disabled) return;

        if (this.handle_selector) {
            let handle = event.target.closest(this.handle_selector);

            if (!this.contains(handle)) return;
        }

        this._position_max.x = Math.max(this.constructor.width_inner__get(this.offsetParent) - this.width_outer__get(), 0);
        this._position_max.y = Math.max(this.constructor.height_inner__get(this.offsetParent) - this.height_outer__get(), 0);
        this._pointer_base.init(event.pageX, event.pageY);
        this._position_base.init(this.left__get(), this.top__get());
        this._position.init_vector(this._position_base);

        this.addEventListener('pointermove', this._on_pointerMove);
        this.setPointerCapture(event.pointerId);

        event.stopPropagation();
        this.dispatchEvent(new CustomEvent('drag_start'));
    }

    _on_pointerMove(event) {
        if (this.axis != 'x') {
            let step = this.step_y || this.step;
            this._position.y = this._position_base.y + Math.round((event.pageY - this._pointer_base.y) / step) * step;
        }

        if (this.axis != 'y') {
            let step = this.step_x || this.step;
            this._position.x = this._position_base.x + Math.round((event.pageX - this._pointer_base.x) / step) * step;
        }

        if (!this.unbounded) {
            this._position.x = Common.toRange(this._position.x, 0, this._position_max.x);
            this._position.y = Common.toRange(this._position.y, 0, this._position_max.y);
        }

        this.attribute__set('_drag', true);

        this._position.round();
        this.left__set(this._position.x);
        this.top__set(this._position.y);

        this.dispatchEvent(new CustomEvent('drag'));
    }

    _on_touchMove(event) {
        event.preventDefault();
    }


    drag__stop() {
        this.attribute__set('_drag');
        this.removeEventListener('pointermove', this._on_pointerMove);
    }
}
