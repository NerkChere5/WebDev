import {Component} from '../Component/Component.js';


export class Switch extends Component {
    static css = true;
    static html = true;
    static observedAttributes = ['disabled', 'on'];
    static url = import.meta.url;


    static {
        this.init();
    }


    _disabled = false;
    _on = false;


    get disabled() {
        return this._disabled;
    }
    set disabled(disabled) {
        this._disabled = !!disabled;
        this.attribute__set('disabled', this._disabled);
    }

    get on() {
        return this._on;
    }
    set on(value) {
        this._on = !!value;
        this.attribute__set('on', this._on);
    }


    _init() {
        this.addEventListener('pointerdown', this._on_pointerDown);
        this.addEventListener('transitionend', this._on_transitionEnd);
    }

    _on_pointerDown() {
        if (this.disabled) return;

        this.attribute__set('_transition', true);
        this.toggle();

        this.dispatchEvent(new CustomEvent('toggle'));
    }

    _on_transitionEnd() {
        this.attribute__set('_transition');
    }


    toggle() {
        this.on = !this._on;
    }
}
