import {Component} from './Component.js';


export class A extends Component {
    static css = true;
    static html = true;
    static url = import.meta.url;

    // static css = `
    //     #root {
    //         border: 1px solid #000;
    //     }
    // `;

    // static html = `
    //     <div id='root'>
    //         Inline
    //     </div>
    // `;


    static {
        this.init();
    }


    _init() {
        this._elements.a.addEventListener('click', () => console.log(this._elements.a));
        this._elements.b.addEventListener('click', () => console.log(this._elements.b));
    }
}
