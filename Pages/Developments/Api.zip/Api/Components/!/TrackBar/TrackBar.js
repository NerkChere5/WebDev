// 18.03.2021


import {Common} from '../../Units/Common/Common.js';
import {Component} from '../Component/Component.js';
import {Draggable} from '../Draggable/Draggable.js';


export class TrackBar extends Component {
    // static _defined = this.init();


    static css = true;
    static html = true;
    static observedAttributes = ['value', 'value_min', 'value_max', 'vertical'];
    static url = import.meta.url;


    static {
        // this.init();
        this._defined = this.init();
    }

    // static _defined = this.init();

    _value = NaN;
    _value_max = 0;
    _value_min = 0;
    _vertical = false;

    _defined = this.constructor._defined;


    get value() {
        return this._value;
    }
    set value(value) {
        let value_prev = this._value;
        this._value = Common.toRange(Math.round(value), this._value_min, this._value_max);

        if (this._value == value_prev) return;

        let puck_position = Math.round(this._elements.puck.step * (this._value - this._value_min));
        this._vertical ? this._elements.puck.top__set(puck_position) : this._elements.puck.left__set(puck_position);
    }

    get value_max() {
        return this._value_max;
    }

    get value_min() {
        return this._value_min;
    }

    get vertical() {
        return this._vertical;
    }
    set vertical(value) {
        this._vertical = !!value;
        this.attribute__set('vertical', this._vertical);

        this._elements.puck.axis = this._vertical ? 'y' : 'x';
        this._elements.puck.left__set();
        this._elements.puck.top__set();

        this.value = this._value;
    }


    async _init() {
        await this._elements.puck._built;

        this._elements.puck.addEventListener('drag', this._puck__on_drag.bind(this));
    }

    _puck__on_drag() {
        let puck_position = this._vertical ? this._elements.puck._position.y : this._elements.puck._position.x;
        this.value = this._value_min + puck_position / this._elements.puck.step;

        this.dispatchEvent(new CustomEvent('value_changed'));
    }


    attributes__apply() {
        this.vertical = this.attribute__get('vertical') ?? this.vertical;
        this.range__set(this.attribute__get('value_min'), this.attribute__get('value_max'));
        this.value = this.attribute__get('value') ?? this.value;
    }

    range__set(value_min, value_max) {
        let puck_length = this._vertical ? this._elements.puck.height_outer__get() : this._elements.puck.width_outer__get();
        let track_length = this._vertical ? this.constructor.height_inner__get(this._elements.track) : this.constructor.width_inner__get(this._elements.track);
        let puck_position_max = track_length - puck_length;

        if (value_max > value_min) {
            this._value_max = value_max;
            this._value_min = value_min;
            this._elements.puck.step = puck_position_max / (this._value_max - this._value_min);
        }
        else {
            this._value_max = puck_position_max;
            this._value_min = 0;
            this._elements.puck.step = 1;
        }

        this.value = this._value;
    }
}
