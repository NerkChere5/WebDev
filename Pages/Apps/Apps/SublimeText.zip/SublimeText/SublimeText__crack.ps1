. '.\SublimeText.ps1';


SublimeText__crack;

timeout -1;
