import sublime
import sublime_plugin

import re




class List(sublime_plugin.ListInputHandler):
  def list_items(this):
    return [str(i) for i in range(0, 10)]
  
  
  # def next_input(this, args):
  #   # return sublime_plugin.BackInputHandler()
  #   return Text()
  
  
  def placeholder(this):
    return 'Test'
  
  
  def preview(this, value):
    return sublime.Html('''
      <style>
        div {
          color: var(--accent);
        }
      </style>
      
      <div>
        ''' + str(value) + '''
      </div>
    ''')


class Text(sublime_plugin.TextInputHandler):
  # def __init__(this, view):
  #   this._view = view
  
  
  def description(this, text):
    return 'Text'
  
  
  def next_input(this, args):
    return List()
  
  
  def placeholder(this):
    return 'Test'
  
  
  def preview(this, text):
    return sublime.Html('''
      <style>
        div {
          color: var(--accent);
        }
      </style>
      
      <div>
        123
      </div>
    ''')




class Test_input(sublime_plugin.TextCommand):
  def input(this, args):
    return Text()
  
  
  def run(this, edit, text, list):
    print(text, list)
