import sublime
import sublime_plugin




class TextMatch(sublime_plugin.ViewEventListener):
    @classmethod
    def applies_to_primary_view_only(self):
        return False




    def __init__(self, *args):
        super().__init__(*args)

        self._regions = []
        self._selection = self.view.sel()
        self._selection_prev_region = None

        self.text_begin = sublime.CLASS_WORD_START
        self.text_end = sublime.CLASS_WORD_END




    def _region__check(self, region):
        return (
            self.view.classify(region.begin()) & self.text_begin
            and self.view.classify(region.end()) & self.text_end
        )


    def _regions__define(self):
        if len(self._selection) > 1: return

        self._regions = []

        if not len(self._selection) or not self._region__check(self._selection[0]): return

        self._regions = [
            region
            for region in self.view.find_all(self.view.substr(self._selection[0]), sublime.LITERAL)
            if self._region__check(region)
        ]


    def _selection_modify__check(self):
        selection_region = self._selection[0] if len(self._selection) else None

        if selection_region == self._selection_prev_region: return False

        self._selection_prev_region = selection_region

        return True


    def _state__display(self):
        if len(self._regions) < 2:
            self.view.erase_regions('TextMatch.region')
            self.view.erase_status('TextMatch.regions_count')

            return

        self.view.add_regions('TextMatch.region', self._regions, scope = 'TextMatch.region', flags = sublime.DRAW_NO_FILL)
        self.view.set_status('TextMatch.regions_count', f'TextMatch.matches_count: {len(self._regions)}')




    def on_modified(self):
        self._regions = []


    def on_selection_modified(self):
        if not self._selection_modify__check(): return

        self._regions__define()
        self._state__display()
