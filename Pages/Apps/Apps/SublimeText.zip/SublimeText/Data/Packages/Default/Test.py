import sublime
import sublime_plugin

((((((   ))))))


class Test(sublime_plugin.TextCommand):
  def _scopes(this):
    i = 0
    i_max = this.view.size()
    view = this.view
    
    while i < i_max:
      # scope = view.scope_name(i)
      b = view.classify(i) & sublime.CLASS_WORD_START
      i += 1
    
    print(b)
  
  
  def _scopeRegions(this):
    selection = this.view.sel()
    
    # if selection[0].empty(): return
    
    regions = this.view.find_by_selector('string')
    regions = [region for region in regions if selection.contains(region)]
    
    if not regions: return
    
    selection.clear()
    selection.add_all(regions)
    
    print('_scopeRegions')
    
    
  
  
  
  def run(this, edit):
    # this._scopes()
    this._scopeRegions()
    
    
    # selection = this.view.sel()
    
    # region = this.view.extract_scope(selection[-1].a)
    
    # if not selection.contains(region): return
    
    # selection.add(region)
    # print(region)
    
    
    # scopes = [this.view.scope_name(region.a) for region in selection]
    # regions = [this.view.find_by_selector(scope) for scope in scopes]
    # regions = [region for region in regions if region.contains(selection[0].a)]
    
    # selection.add_all(regions)
    
    
    # print(regions)
    
    
    pass
