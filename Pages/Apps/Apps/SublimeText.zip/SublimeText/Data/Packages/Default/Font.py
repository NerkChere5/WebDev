import sublime
import sublime_plugin




class Font__resize(sublime_plugin.WindowCommand):
    def __init__(self, *args):
        super().__init__(*args)

        self._font_size = None

        self.font_size_max = 50
        self.font_size_min = 2




    def _font_size__define(self, increment = 0):
        self._font_size = None

        if not increment: return

        font_size = self.window.active_view().settings().get('font_size') + increment
        self._font_size = min(max(font_size, self.font_size_min), self.font_size_max)


    def _settings__set(self, view):
        settings = view.settings()

        if self._font_size:
            settings.set('font_size', self._font_size)
        else:
            settings.erase('font_size')




    def run(self, all = False, increment = 0):
        self._font_size__define(increment)

        if all:
            for view in self.window.views():
                self._settings__set(view)
        else:
            self._settings__set(self.window.active_view())
