import sublime
import sublime_plugin

import re




class A(sublime_plugin.TextCommand):
  _edit = None
  
  
  
  
  def _a(this, a, b):
    print(this._s + '_' + a + '_' + b)
  
  
  def _sort(this):
    regions = []
    regions_full = []
    strings = []
    
    selection = this.view.sel()
    
    for region in selection:
      # if region.empty() or len(this.view.lines(region)) != 1:
      if len(this.view.lines(region)) != 1:
        selection.subtract(region)
        
        continue
      
      region_full = this.view.line(region)
      region_full_prev = regions_full[-1] if len(regions_full) else None
      
      if region_full == region_full_prev:
        selection.subtract(region)
        
        continue
      
      regions_full.append(region_full)
      strings.append({
        'full': this.view.substr(region_full),
        'sort': this.view.substr(region),
      })
    
    if len(selection) < 2: return
    
    # regions.sort(key = lambda region: this.view.substr(region['sort']))
    strings.sort(key = lambda string: string['sort'])
    # strings.sort(key = lambda string: string['sort'], reverse = True)
    
    # this.view.replace(this._edit, regions[0]['sort'], 'abc')
    
    print(selection)
    
    # for i, region in enumerate(selection):
    for i in range(len(selection) - 1, -1, -1):
      selection.add(this.view.line(selection[i]))
      # this.view.replace(this._edit, this.view.line(region), strings[i]['full'])
      this.view.replace(this._edit, this.view.line(selection[i]), strings[i]['full'])
      # this.view.replace(this._edit, this.view.line(region), 'abc')
      # this.view.replace(this._edit, region, 'abc')
      # this.view.replace(this._edit, region, strings[i]['sort'])
      
    
    print(selection)
  
  
  def _structure(this):
    selection = this.view.sel()
    
    # string = '[asd, [1, 2, 3]]'
    string = '{a: 1, b: 2, c: [1, 2, 3]}'
    
    
    # string = re.sub(r'\[(.*)\] *', r'[\n\t\1\n]', string)
    # print(string)
    # this.view.replace(this._edit, selection[0], string)
    # this.view.run_command('insert_snippet', args = {'contents': string})
    
    
    indent = 0
    # string = re.sub(r'(?<!:) *([\[\](){},]) *', r'\1', string)
    string = re.sub(r'\s*([\[\](){},])\s*', r'\1', string)
    string = re.sub(r'\s*:\s*', r': ', string)
    string_indented = ''
    
    for char in string:
      if char in '([{':
        indent += 1
        string_indented += char + '\n' + '\t' * indent
      elif char in ')]}':
        indent -= 1
        string_indented += ',\n' + '\t' * indent + char
      elif char in ',':
        string_indented += char + '\n' + '\t' * indent
      else:
        string_indented += char
    
    print(string)
    # print(string_indented)
    
    # this.view.replace(this._edit, selection[0], string_indented)
    this.view.run_command('insert_snippet', args = {'contents': string_indented})
  
  
  def _test(this):
    pass
  
  
  
  
  def run(this, edit, a = 1, b = 2):
    this._edit = edit
    
    # this._sort()
    this._test()




class Sort__chars(sublime_plugin.TextCommand):
  def run(this, edit):
    for region in this.view.sel():
      string = this.view.substr(region)
      string_processed = ''.join(sorted(set(string)))
      
      if string_processed == string: continue
      
      this.view.replace(edit, region, string_processed)
