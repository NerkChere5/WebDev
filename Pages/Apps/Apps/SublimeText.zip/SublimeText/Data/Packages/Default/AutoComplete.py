import sublime
import sublime_plugin




class AutoComplete(sublime_plugin.ViewEventListener):
    @classmethod
    def applies_to_primary_view_only(self):
        return False




    def __init__(self, *args):
        super().__init__(*args)

        self._completionList = None
        self._points = []
        self._prefix = ''
        self._words = {}

        self.completionList_flags = sublime.INHIBIT_REORDER | sublime.INHIBIT_WORD_COMPLETIONS




    def _completionList__define(self):
        self._completionList = sublime.CompletionList()

        if not self._points__check(): return

        completionItems = []
        words = sorted(self._words.keys())
        words.sort(key = lambda word: self._words[word], reverse = True)

        for word in words:
            completionItem = sublime.CompletionItem(word, str(self._words[word]))
            completionItems.append(completionItem)

        self._completionList.set_completions(completionItems, self.completionList_flags)


    def _points__check(self):
        for point in self._points:
            point_class = self.view.classify(point)

            if point_class & sublime.CLASS_WORD_START or self._prefix and not point_class & sublime.CLASS_WORD_END: return False

        return True


    def _words__define(self):
        self._words = {}

        word = ''
        word_separators = self.view.settings().get('word_separators') + ' \n\r\t'
        content = self.view.substr(sublime.Region(0, self.view.size())) + word_separators[0]

        for char in content:
            if char in word_separators:
                if not word: continue

                if word in self._words:
                    self._words[word] += 1
                elif word != self._prefix:
                    self._words[word] = 1

                word = ''

                continue

            word += char




    def on_query_completions(self, prefix, points):
        self._points = points
        self._prefix = prefix
        self._words__define()
        self._completionList__define()

        return self._completionList
