import sublime
import sublime_plugin




class Scopes__show(sublime_plugin.TextCommand):
    html = '''
        <style>
            html {{
                background-color: transparent;
            }}


            .list__caption {{
                font-family: system;
                font-size: 1.2rem;
                font-weight: bold;
                margin: 0 0 0.5em 0;
            }}

            .list__item {{
                color: var(--foreground);
                display: block;
                text-decoration: none;
            }}
        </style>


        {content}
    '''
    html__list = '''
        <div class='list'>
            <div class='list__caption'>Scopes</div>
            <div class='list__meta_items'>{content}</div>
        </div>
    '''
    html__list__item = '''
        <a class='list__item' href='{content}' title='Copy'>{content}</a>
    '''




    def __init__(self, *args):
        super().__init__(*args)

        self._selection = None
        self._scopes = []




    # def _menu__on_done(self, item_num):
    #     scope = self.view.scope_name(self._selection[0].b)
    #     regions = self.view.find_by_selector(scope)
    #     regions = [self._selection.contains(region) for region in regions]
    #     self._selection.add_all(regions)




    def _list__on_navigate(self, href):
        self.scope__copy(href)




    def run(self, edit):
        self._selection = self.view.sel()

        if not self._selection: return

        # scopes = self.view.scope_name(selection[0].b).rstrip().split(' ')
        self._scopes = self.view.scope_name(self._selection[0].b).rstrip().split(' ')

        htmls__list__items = [self.html__list__item.format(content = scope) for scope in self._scopes]
        html__list__items = ''.join(htmls__list__items)
        html__list = self.html__list.format(content = html__list__items)
        html = self.html.format(content = html__list)

        self.view.show_popup(
            content = html,
            max_height = 300,
            max_width = 500,
            on_navigate = self._list__on_navigate,
        )

        # self.view.show_popup_menu(self._scopes, self._menu__on_done)

        # self.view.add_regions(
        #     key = 'a',
        #     regions = self._selection,
        #     scope = 'keyword',
        #     flags = sublime.DRAW_NO_FILL,
        #     annotations = [html],
        # )


    def scope__copy(self, scope):
        sublime.set_clipboard(scope)
        self.view.hide_popup()

        sublime.status_message('Scopes.scope__copy: ' + scope)
