import sublime
import sublime_plugin




class UndoStack__clear(sublime_plugin.WindowCommand):
    def run(self, all = False):
        if all:
            for view in self.window.views():
                view.clear_undo_stack()
        else:
            self.window.active_view().clear_undo_stack()
