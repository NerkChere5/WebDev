let a = typeof /re/++ / typeof typeof ++/re/ga++ instanceof /re/.a + `a${a + true}b`;
let a = (1, 2), b = {a: 1, 'b': 2, [c, d]: 3, 0xa: 4, ...d, }
let a = [1, 2, ...[3, 4]];
var a = true?a.a:b?.b;
let a = 1, b = 2;
let [a, b] = [1, 2], {a: a = 1, b: b, ...c} = {a: 1, b: 2};

label:
(f(a, ...b.#for,)(a, b), s) + a?.[1, 2];

{
    async + async/**/function* f() {
        return /re/i;
        return async function async(...a) {};
        return {a: 1, b: 2};
        return 1, 2;
    }

    class A extends B.a {
        async
        () {}
        get
        () {}
        static get
        static async
        static #static
        *get() {}
        *async() {}
        get #a() {}
        async */**/a() {}
        async /*aaa*/ /*aaa*/*async() {}

        static ab = 1;
        static static
        static static = this
        static {
            let a = a;
        }

        static a() {}
        static get b() {}
        static get c() {}
        static async /**/ *d() {}

        get() {}
        async() {}
        get() {}
    }

    let a = class extends a.B {a = 1; b = 2;} / /re/;

    let a = {
        a: 1,
        a() {},
        async a() {},
        get a() {},
    };

    let a = async/**/=> null;
    let a = async/**/async/**/=> null;
    let a = async / async async => null;
    let a = async async async async => null;
    let a = ()/**/=> {return null};
    let a = async (
        a, b
    ) => null;

}


async async => null;

