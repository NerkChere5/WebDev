label
:

let a = 1, b = (1 + 2, 3 / 4) + [1, (2), ...[3,,],], c = true ?.0 : a.for.while?.#c[1, 2](1_2.3_4e5_6, 2e1, ...a);
let o = {for: 1, 'b': 2, [c, d]: 3, 0xa: /4/gim / /5[\]]/, ...d && e, };
let [a, b] = [1, 2];
let {a, b} = {a: 1, b: 2};
var s = `aaa${a + b}bbb`;
var re = /a[d\]s]/yield;

o = {
    a: 1,

    ['b']: {a: 1},

    'key': 1,

    a: async /**/ function () {} + 1,

    f(a, b = 1, ...c) {
        return 1, 2;
    },

    async () {},

    get () {},

    set
    a() {},

    *
    g(a, b) {},

    async /**/ *f() {},

    async /**//*
    */ *g() {},

    async /**//**/
    *g() {},
};


awaitasync;
async
: 1;
async /**/ function *let(a, ...b, ...c) {}
async /*
*/ function *f() {};

async(...[1, 2], 3);
async /**/ => /**/ 1, 2;
async/**/async /**/ => null;
async /**/ () /**/ => {return null};

a => {return 1};
(a, b = 1) /**/ => {return null}, 1;
// async /**/ (


class A {};
class A extends class extends class {} {} {};

class A extends B.a {
    1 = 1;;

    async
    () {}
    get
    () {}
    *get() {}
    *async() {}
    get #a() {}
    async */**/a() {}
    async /*aaa*/ /*aaa*/*async() {}

    static a
    static b
    static static
    static static = this

    static {
        let a = a;
    }

    static a() {}
    static get b() {}
    static get c() {}
    static async /**/ *d() {}
}


void 1;
yield/**/* /**/ 1;
a = yield/**/* /**/ 1;

return /**/ {a: 1};
break /**/ label;


for (var p in {a: 1});
for (p in {a: 1});
for await (of of of of of);
for await (let [a, b] of of of of);
for (;;);
for (i = 0, j = 0; i < 9, j < 9; i++, j++);
for (let i = 0, j = 0; i < 9, j < 9; i++, j++);


if () {}

import.meta.url;
import('./');

import defaultExport from "./";
import * as name from "./";
import { default as alias } from "./";
import { export1, export2 } from "./";
import { export1, export2 as alias2 } from "./";
import { "string name" as alias } from "./";
import defaultExport, { export1} from "./";
import defaultExport, * as name from "./";
import "./";


// Exporting declarations
export let name1, name2/*, … */; // also var
export const name1 = 1, name2 = 2/*, … */; // also var, let
export const { name1, name2: bar } = o;
export const [ name1, name2 ] = array;
export class ClassName { /* … */ }
export function functionName() { /* … */ }
export function* generatorFunctionName() { /* … */ }

// Export list
export { name1, /* …, */ nameN };
export { variable1 as name1, variable2 as name2, /* …, */ nameN };
export { variable1 as "string name" };
export { name1 as default /*, … */ };

// Default exports
export default expression;
export default function functionName() { /* … */ }
export default class ClassName { /* … */ }
export default function* generatorFunctionName() { /* … */ }
export default function () { /* … */ }
export default class { /* … */ }
export default function* () { /* … */ }

// Aggregating modules
export * from "module-name";
export * as name1 from "module-name";
export { name1, /* …, */ nameN } from "module-name";
export { import1 as name1, import2 as name2, /* …, */ nameN } from "module-name";
export { default, /* …, */ } from "module-name";
export { default as name1 } from "module-name";


1:a

switch (expr) {
  case 'Oranges':
    console.log('Oranges are $0.59 a pound.');
    break;
  case a ? 1 : 2:
  case 'Papayas':
    console.log('Mangoes and papayas are $2.79 a pound.');
    // Expected output: "Mangoes and papayas are $2.79 a pound."
    break;
  default:
    console.log(`Sorry, we are out of ${expr}.`);
}


new.target
