function SublimeText__contextMenu__add() {
    $app_name = 'SublimeText';
    $app_path = (get-location).path + "\$app_name.exe";
    $folder_name = 'SublimeText';
    $menu_caption = 'SublimeText';
    $reg_dir = "HKEY_CLASSES_ROOT\*\shell\$folder_name";

    reg add $reg_dir /v 'Position' /t REG_SZ /d 'Top' /f;
    reg add $reg_dir /ve /d $menu_caption /f;
    reg add "$reg_dir\Command" /ve /d "$app_path \`"%1\`"" /f;
}

function SublimeText__crack() {
    $app_bytes = [system.io.file]::readAllBytes('./sublime_text.exe');

    $bytes_offsets = @(
        0x000A0DBC,
        0x0000647C,
        0x00006495,
        0x000A2B52,
        0x000A0983
    );
    $bytes_replaces = @(
        @(0x48, 0xC7, 0xC0, 0x00, 0x00, 0x00, 0x00, 0xC3),
        @(0x90, 0x90, 0x90, 0x90, 0x90),
        @(0x90, 0x90, 0x90, 0x90, 0x90),
        @(0xC3),
        @(0xC3)
    );

    for ($i = 0; $i -lt $bytes_replaces.count; $i++) {
        $bytes_offset = $bytes_offsets[$i];
        $bytes_replace = $bytes_replaces[$i];

        for ($j = 0; $j -lt $bytes_replace.count; $j++) {
            $app_bytes[$bytes_offset + $j] = $bytes_replace[$j];
        }
    }

    [system.io.file]::writeAllBytes('./SublimeText_new.exe', $app_bytes);
}
