. '.\SublimeText.ps1';


SublimeText__contextMenu__add;

timeout -1;
