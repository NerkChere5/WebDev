<?php

// $cfg['Servers'][$i]['AllowNoPassword'] = true;
// $cfg['blowfish_secret'] = '12345678901234567890123456789012';
